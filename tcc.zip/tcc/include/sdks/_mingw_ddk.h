#ifndef MINGW_HAS_DDK_H

#define MINGW_HAS_DDK_H 1
/* DDK Version of ReactOS rev40585.  */

#endif
